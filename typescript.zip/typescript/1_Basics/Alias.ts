type chars1 = string;
let mes1: chars1;
mes1="God Is Great.";
console.log(mes1);


type alphanumeric1= string | number;
let input1: alphanumeric1;
input1 = 1; 
input1 = "God Is Great."; 
