var mes1;
mes1 = "God Is Great.";
console.log(mes1);
var input1;
input1 = 1;
input1 = "God Is Great.";
