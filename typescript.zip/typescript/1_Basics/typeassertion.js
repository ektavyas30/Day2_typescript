// Bracket 
var empCode = 111; // Not Viable.
var employeeCode = empCode;
console.log("Type is:" + typeof (employeeCode)); //Output: number  
// AS
var empCode2 = 111;
var employeeCode2 = empCode;
console.log("Type is:" + typeof (employeeCode2)); //Output: number  
// Initialization.
var p = {};
p.code = 1; // Correct  
p.name = "Ekta"; // Correct  
