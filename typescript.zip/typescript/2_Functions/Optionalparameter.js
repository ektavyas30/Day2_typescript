function sum(a, b, c, d) {
    if (typeof c !== 'undefined' && typeof d !== 'undefined') {
        return a + b + c + d;
    }
    return a + b;
}
console.log(sum(10, 20, 30, 40));
console.log(sum(10, 20));
