
function sum(...numbers: number[]): number {
    let total = 0;
    numbers.forEach((num) => total += num);
    return total;
}

console.log("No Arguments: "+sum()); 
console.log("2 Arguments: "+sum(10, 20)); 
console.log("3 Arguments: "+sum(10, 20, 30)); 

