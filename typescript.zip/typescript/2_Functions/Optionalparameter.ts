
function sum(a: number, b: number, c?: number, d?: number ): number {
    if (typeof c !== 'undefined' && typeof d !== 'undefined') {
        return a + b +c +d;
    }
    return a + b ;
}

console.log(sum(10,20,30,40));
console.log(sum(10,20));




